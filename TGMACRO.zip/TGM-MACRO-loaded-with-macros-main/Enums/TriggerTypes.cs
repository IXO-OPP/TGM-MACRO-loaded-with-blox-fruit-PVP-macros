﻿namespace TGMacro.Enums
{
    public enum TriggerTypes
    {
        Mouse = 0,
        Keyboard = 1,
        Pixel = 2
    }
}
