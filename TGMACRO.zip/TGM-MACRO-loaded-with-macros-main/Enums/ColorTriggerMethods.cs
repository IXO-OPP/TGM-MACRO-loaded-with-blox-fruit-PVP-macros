﻿namespace TGMacro.Enums
{
    public enum ColorTriggerMethods
    {
        ColorMatches,
        ColorNotMatches
    }
}
