﻿namespace TGMacro.Enums
{
    public enum TriggerRunState
    {
        Stop,
        RunOnce,
        Run
    }
}
