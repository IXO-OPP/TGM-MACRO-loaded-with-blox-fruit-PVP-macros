﻿namespace TGMacro.Enums
{
    public enum ActionTypes
    {
        MoveMouse = 0,
        MouseButton = 1,
        KeyboardKey = 2,
        Wait = 3,
        Text = 4,
    }
}
