﻿namespace TGMacro.Enums
{
    public enum TriggerKeyMethods
    {
        Press = 0,
        Hold = 1,
        Toggle = 2,
    }
}
