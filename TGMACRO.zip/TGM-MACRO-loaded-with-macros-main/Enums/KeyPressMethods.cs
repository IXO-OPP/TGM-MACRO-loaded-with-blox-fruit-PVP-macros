﻿namespace TGMacro.Enums
{
    public enum KeyPressMethods
    {
        Press = 0,
        Down = 1,
        Up = 2
    }
}
