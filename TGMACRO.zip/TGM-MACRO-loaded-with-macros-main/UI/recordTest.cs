﻿using System.Windows.Forms;

namespace TMacro
{
    public partial class recordTest : Form
    {
        public recordTest()
        {
            InitializeComponent();
        }
    }
}
